<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Book My Travel</title>
   
  

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        .col-md-3{
          display: inline-block;
          margin-left:-4px;
        }
        .col-md-3 img{
          width:100%;
          height:auto;
        }
        body .carousel-indicators li{
          background-color:red;
        }
        body .carousel-indicators{
          bottom: 0;
        }
        body .carousel-control-prev-icon,
        body .carousel-control-next-icon{
          background-color:red;
        }
        body .no-padding{
          padding-left: 0;
          padding-right: 0;
        }
        .carousel-images{
            width: 253;
            height: 146;
        }
    </style>
</head>
<body>
<!--header -->
<?php
include 'includes/header_menu.php';
include 'includes/check-if-added.php';
?>
<!--header ends -->
<div class="container" style="margin-top:65px">
   
    
    <img width="1107px" height="338px" src="./images/travel.jpg">
  
  
    <hr/>
    <!--menu list-->
    <div class="row text-center" id="watch">
        <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="container carousel-inner no-padding">
                <div class="carousel-item active">
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/united.jpg" width="253" height="146" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                                <h6>Atlanta To Mumbai</h6>
                                <h6>Departure 2021-05-11 12:45</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F1" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>    
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/delta.jpeg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>New York To Delhi</h6>
                                <h6>Departure 2021-05-18 12:45</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F2" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>   
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/ai.jpg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>Atlanta To Hyderabad</h6>
                                <h6>Departure 2021-05-11 12:45</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F5" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>   
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/united.jpg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>Chicago To Dubai</h6>
                                <h6>Departure 2021-06-11 12:45</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F3" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>   
                </div>
                <div class="carousel-item">
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/united.jpg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>Atlanta To Paris</h6>
                                <h6>Departure 2021-05-28 12:45</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="cseating-chart.php?id=F4" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>    
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/delta.jpeg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>New York To Paris</h6>
                                <h6>Departure 2021-07-08 00:20</h6>
                                <h6>Price :$800</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F6" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>   
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/united.jpg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>Chicago To Hederabad</h6>
                                <h6>Departure 2021-08-12 00:21</h6>
                                <h6>Price :$900</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F7" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>   
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/united.jpg" alt="" class="img-fluid pb-1 carousel-images" >
                            <div class="figure-caption">
                                <h6>New York To Paris</h6>
                                <h6>Departure 2021-05-13 00:23</h6>
                                <h6>Price :$900</h6>
                                <?php 
                                    if (!isset($_SESSION['email'])) {?>
                                        <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Book A Seat</a></p>
                                    <?php
                                    } 
                                    else {
                                        if (check_if_added_to_cart(1)) {
                                            echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                        } 
                                        else {
                                            ?>
                                            <p><a href="seating-chart.php?id=F8" name="add" value="add" class="btn btn-warning  text-white">Book A Seat</a><p>
                                        <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>  
                </div>
                
            </div>
  
            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </div>

    <div id="demo1" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
                <li data-target="#demo1" data-slide-to="0" class="active"></li>
                <li data-target="#demo1" data-slide-to="1"></li>
                <li data-target="#demo1" data-slide-to="2"></li>
            </ul>
            <div class="container carousel-inner no-padding">
                <div class="carousel-item active">
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card">
                            <img src="images/camry.png" alt="" class="img-fluid pb-1"  >
                            <div class="figure-caption">
                            <h6>Toyota Camry</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Mumbai</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(5)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V1" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                                }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="carousel-item">
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 py-3">
                        <div class="card">
                            <img src="images/corolla.jpg" alt="" class="img-fluid pb-1" >
                            <div class="figure-caption">
                            <h6>Toyota Corolla</h6>
                            <h6>Price :$800/hr</h6>
                            <h6>City :Delhi</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                            <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                            <?php
                            } else {
                                if (check_if_added_to_cart(6)) {
                                echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                                } else {
                                ?>
                                <p><a href="cart-add.php?id=V2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                                <?php
                            }
                            }
                            ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <a class="carousel-control-prev" href="#demo1" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo1" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>

        <div id="demo2" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
                <li data-target="#demo1" data-slide-to="0" class="active"></li>
                <li data-target="#demo1" data-slide-to="1"></li>
                <li data-target="#demo1" data-slide-to="2"></li>
            </ul>
            <div class="container carousel-inner no-padding">
                <div class="carousel-item active">
                    <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/Atlanta.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Atlanta</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(9)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    <p><a href="parking.php?id=9" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/LA1.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Las Vegas</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(10)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                     <p><a href="parking.php?id=10" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                     <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/hongkong.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Hong Kong</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(11)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    <p><a href="parking.php?id=11" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3" >
                    <div class="card">
                        <img src="images/moscow.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                        <h6>Moscow</h6>
                    <h6>Book a Parking spot</h6>
                    <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(12)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    </p><a href="parking.php?id=12" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                </div>
                <div class="carousel-item">
                    <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/Atlanta.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Atlanta</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(9)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    <p><a href="parking.php?id=9" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/LA1.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Las Vegas</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(10)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                     <p><a href="parking.php?id=10" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                     <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3">
                    <div class="card">
                        <img src="images/hongkong.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                            <h6>Hong Kong</h6>
                            <h6>Book a Parking spot</h6>
                            <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(11)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    <p><a href="parking.php?id=11" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 py-3" >
                    <div class="card">
                        <img src="images/moscow.jpeg" alt="" class="img-fluid pb-1">
                        <div class="figure-caption">
                        <h6>Moscow</h6>
                    <h6>Book a Parking spot</h6>
                    <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Click to Book</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(12)) {
                    echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                    ?>
                    </p><a href="parking.php?id=12" name="add" value="add" class="btn btn-warning  text-white">Click to Book</a></p>
                    <?php
                    }
                    }
                    ?>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#demo2" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo2" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>

      <!--menu list ends-->
      <!-- footer-->
        <?php include 'includes/footer.php'?>
      <!--footer ends-->
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
  $('[data-toggle="popover"]').popover();
});
</script>
<?php if (isset($_GET['error'])) {$z = $_GET['error'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#signup').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";}?>
<?php if (isset($_GET['errorl'])) {$z = $_GET['errorl'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#login').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";}?>
</html>