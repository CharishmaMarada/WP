<?php
require("includes/common.php");
session_start();
if (isset($_GET['id'])) {
    $item_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    $query = "SELECT * FROM flights WHERE id='$item_id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    $seatsAvailable = $row['availableSeats'];
    #header('location: products.php');


}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Seating Chart</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
	<link rel="stylesheet" href="main.css">
</head>
<body>
<div class="container">
	<div id="wings"></div>
	<div id="seatmap">
	    <div id="plane">
	        <!-- <table class="rows">
	            <tr>
	                <td>J</td>
	            </tr>
	            <tr>
	                <td>G</td>
	            </tr>
	            <tr>
	                <td></td>
	            </tr>
	            <tr>
	                <td>F</td>
	            </tr>
	            <tr>
	                <td>E</td>
	            </tr>
	            <tr>
	                <td>D</td>
	            </tr>
	            <tr>
	                <td></td>
	            </tr>
	            <tr>
	                <td>C</td>
	            </tr>
	            <tr>
	                <td>A</td>
	            </tr>
	        </table> -->
	        
	        <div id="cabin">        
	            <table>
	            <tr>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	            </tr>
	            <tr>
	                <td title="1J" class="seatUnavailable"></td>
	                <td title="2J" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4J" class="seatUnavailable"></td>
	                <td title="5J" class="seatUnavailable"></td>
	                <td title="6J" class="seatUnavailable"></td>
	                <td title="7J" class="seatUnavailable"></td>
	                <td title="8J" class="noSeatStorage"></td>
	                <td title="9J" class="seatUnavailable"></td>
	                <td title="10J" class="seatUnavailable"></td>
	                <td title="11J" class="seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td title="1G" class="seatUnavailable"></td>
	                <td title="2G" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4G" class="seatUnavailable"></td>
	                <td title="5G" class="seatUnavailable"></td>
	                <td title="6G" class="seatUnavailable"></td>
	                <td title="7G" class="seatUnavailable"></td>
	                <td title="8G" class="noSeatStorage"></td>
	                <td title="9G" class="seatUnavailable"></td>
	                <td title="10G" class="seatUnavailable"></td>
	                <td title="11G" class="seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td class="noSeatGalley">1</td>
	                <td class="noSeatGalley">2</td>
	                <td class="noSeatGalley"></td>
	                <td class="noSeatGalley">4</td>
	                <td class="noSeatGalley">5</td>
	                <td class="noSeatGalley">6</td>
	                <td class="noSeatGalley">7</td>
	                <td class="noSeatGalley">8</td>
	                <td class="noSeatGalley">9</td>
	                <td class="noSeatGalley">10</td>
	                <td class="noSeatGalley">11</td>
	            </tr>
	            <tr>
	                <td title="1F" class="seatUnavailable"></td>
	                <td title="2F" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4F" class="seatUnavailable"></td>
	                <td title="5F" class="seatUnavailable"></td>
	                <td title="6F" class="seatUnavailable"></td>
	                <td title="7F" class="seatUnavailable"></td>
	                <td title="8F" class="noSeatLavatory"></td>
	                <td title="9F" class="seatUnavailable"></td>
	                <td title="10F" class="seatUnavailable"></td>
	                <td title="11F" class="seatUnavailable seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td title="1E" class="seatUnavailable"></td>
	                <td title="2E" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4E" class="seatUnavailable"></td>
	                <td title="5E" class="seatUnavailable wingSeat"></td>
	                <td title="6E" class="seatUnavailable wingSeat"></td>
	                <td title="7E" class="seatUnavailable wingSeat"></td>
	                <td title="8E" class="noSeatLavatory wingSeat"></td>
	                <td title="9E" class="seatUnavailable"></td>
	                <td title="10E" class="seatUnavailable"></td>
	                <td title="11E" class="seatUnavailable seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td title="1D" class="seatUnavailable"></td>
	                <td title="2D" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4D" class="seatUnavailable"></td>
	                <td title="5D" class="seatUnavailable"></td>
	                <td title="6D" class="seatUnavailable"></td>
	                <td title="7D" class="seatUnavailable"></td>
	                <td title="8D" class="noSeatLavatory"></td>
	                <td title="9D" class="seatUnavailable"></td>
	                <td title="10D" class="seatUnavailable"></td>
	                <td title="11D" class="seatUnavailable seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td class="noSeatGalley">1</td>
	                <td class="noSeatGalley">2</td>
	                <td class="noSeatGalley"></td>
	                <td class="noSeatGalley">4</td>
	                <td class="noSeatGalley">5</td>
	                <td class="noSeatGalley">6</td>
	                <td class="noSeatGalley">7</td>
	                <td class="noSeatGalley">8</td>
	                <td class="noSeatGalley">9</td>
	                <td class="noSeatGalley">10</td>
	                <td class="noSeatGalley">11</td>
	            </tr>
	            <tr>
	                <td title="1C" class="seatUnavailable"></td>
	                <td title="2C" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4C" class="seatUnavailable"></td>
	                <td title="5C" class="seatUnavailable"></td>
	                <td title="6C" class="seatUnavailable"></td>
	                <td title="7C" class="seatUnavailable"></td>
	                <td title="8C" class="noSeatLavatory"></td>
	                <td title="9C" class="seatUnavailable"></td>
	                <td title="10C" class="seatUnavailable"></td>
	                <td title="11C" class="seatUnavailable seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td title="1A" class="seatUnavailable"></td>
	                <td title="2A" class="seatUnavailable"></td>
	                <td title="" class="noSeatGalley"></td>
	                <td title="4A" class="seatUnavailable"></td>
	                <td title="5A" class="seatUnavailable"></td>
	                <td title="6A" class="seatUnavailable"></td>
	                <td title="7A" class="seatUnavailable"></td>
	                <td title="8A" class="noSeatLavatory"></td>
	                <td title="9A" class="seatUnavailable"></td>
	                <td title="10A" class="seatUnavailable"></td>
	                <td title="11A" class="seatUnavailable seatUnavailable"></td>
	            </tr>
	            <tr>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	                <td></td>
	            </tr>
	            </table>            
	        </div>
	        <div style="clear: both;"></div>
	    </div>
	</div>
	<div id="wings"></div>
	<form style="text-align: center;"  action="./cart-add.php" method="GET">
		<?php echo '<input type="text" style="display:none" name="id" id="id" value="'.$item_id.'">';?>
		<input type="text" style="display:none" id="seat" name="seat">
		<br>
		<button name="submit" class="btn">Buy Seat</button>
		<?php echo '<input style="display:none" type="text" name="seatsAv" id="seatsAv" value="'.$seatsAvailable.'">';?>
	</form>
	
</div>
</body>
</html>