<?php
$server = "localhost";
$user = "root";
$pass = "root";
$database = "ecommerce";
$port = 3306;
$con = new mysqli($server, $user, $pass, $database);

if($con -> connect_error){
    die("connection failed! ". $con -> connect_error);
}
?>
