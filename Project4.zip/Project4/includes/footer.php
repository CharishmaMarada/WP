<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Book My Travel</b></span></div>
</footer>
    