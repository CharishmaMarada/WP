$( document ).ready(initialSetUp);

function initialSetUp(){
	$('id')
	$('.noSeatStorage').html('S');
	$('.noSeatLavatory').html('L');
	$('.ExtraPay').html('E');
	$('.LargeSeat').html('XL');

	$("td").click(function(){
		$("#seat").val(this.title);
		var selector = "td[title="+this.title+"]";
		$(selector).css("background-color","yellow");
	});

	var availableSeats = $("#seatsAv").val();
	var seats = availableSeats.split(",");

	seats.forEach(function(seat){
		var selector = "td[title="+seat+"]";
		$(selector).removeClass("seatUnavailable");
		$(selector).addClass("seatAvailable");
	});
}

