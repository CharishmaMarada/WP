CREATE TABLE `products` (
  `id` VARCHAR(100) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `products` (`id`, `name`, `price`) VALUES
('F1', 'F1', 3000),
('F2', 'F2', 2500),
('F3', 'F3', 3500),
('F4', 'F4', 1800),
('F5', 'F5', 1800),
('F6', 'F6', 2500),
('F7', 'F7', 500),
('F8', 'F8', 2300);
