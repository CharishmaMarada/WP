<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
    <link href='https://fonts.googleapis.com/css?family=Delius Swash Caps' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Andika' rel='stylesheet'>
    <link rel="stylesheet" href="images/styles.css">
    <title>Book Parking</title>
</head>

<body>

    <div id="parking">

        <h1>Parking</h1>
        <form action="processParking.php" method="POST">

            <div id="pimgs" class="row">

                <div class="col">
                    <img src="images/Parking_Map.jpeg" alt="parking-zone" id="pimg1">
                </div>

                <div class="col">
                    <img src="images/pricing.png" alt="parking-prices" id="pimg2">
                </div>

            </div>

            <div class="row">
                <?php include 'displayParking.php'; ?>
            </div>

            <br><br>
            <div id="paddTC" class="row">
                <a id="phome" href="products.php"><input type="button" class="button" id="btn1" value="Home"></a>
                <input id="phome" type="submit" class="button" value="Add to Cart">
            </div>
        </form><br>

    </div>

</body>

</html>