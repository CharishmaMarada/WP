<?php
require "includes/common.php";
session_start();
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}

$user_id = $_SESSION['user_id'];
$query1 = " SELECT users.email_id AS email, users.first_name AS fname, users.last_name AS lname, users.phone AS phone FROM users WHERE users.id='$user_id'";

$result1 = mysqli_query($con, $query1);
$row = mysqli_fetch_assoc($result1);
$email = $row['email'];
$fname = $row['fname'];
$lname = $row['lname'];
$phone = $row['phone'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body style="background-image: url('images/orders.jpg'); background-repeat: no-repeat, repeat;background-size: cover;">
	<br>
	<br>
	<div class="container">
		<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#personal">Personal Information</button>
		<br>
		<br>
		<div id="personal" class="collapse">
			<br>
			<h6 style="float: left;margin-right: 10px;"><b>First Name: </b></h6>
			<?php echo '<h6>'.$fname.'</h6>';?>
			<h6 style="float: left;margin-right: 10px;"><b>Last Name: </b></h6>
			<?php echo '<h6>'.$lname.'</h6>';?>
			<h6 style="float: left;margin-right: 10px;"><b>E-mail: </b></h6>
			<?php echo '<h6>'.$email.'</h6>';?>
			<h6 style="float: left;margin-right: 10px;"><b>Phone: </b></h6>
			<?php echo '<h6>'.$phone.'</h6>';?>
		</div>
		<button type="button" class="btn btn-info" data-toggle="collapse" data-target="#orders">Order History</button>
		<br>
		<div id="orders" class="collapse">
			<br>
			<?php
			$query = " SELECT products.price AS Price, products.id, products.name AS Name, products.type AS Type, users_products.purchaseDate AS PurchaseDate FROM users_products JOIN products ON users_products.item_id = products.id WHERE users_products.user_id='$user_id' and status='Confirmed'";
			
			$result = mysqli_query($con, $query);
			while ($row = mysqli_fetch_array($result)) {?>
				<br>
				<br>
				<br>
				<br>
				<img src="images/flight.jpg" width="253" height="146" alt="" class="img-fluid pb-1" style="float: left;clear: both" >
				<h6 style="float: left;margin-right: 10px;"><b>Product Name: </b></h6>
				<h6><?= $row['Name']?></h6>
                <h6 style="float: left;margin-right: 10px;"><b>Product Price: </b></h6>
				<h6><?= $row['Price']?></h6>
				<h6 style="float: left;margin-right: 10px;"><b>Product Type: </b></h6>
				<h6><?= $row['Type']?></h6>
				<h6 style="float: left;margin-right: 10px;"><b>Purchase Date: </b></h6>
				<h6><?= $row['PurchaseDate']?></h6>

			<?php
			}
			?>
			
		</div>
		
	</div>
</body>
</html>